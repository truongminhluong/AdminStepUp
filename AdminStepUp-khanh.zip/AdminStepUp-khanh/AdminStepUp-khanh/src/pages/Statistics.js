const GiftCards = () => {
    return <div>Thống kê</div>;
};

export default GiftCards; // Phải export đúng