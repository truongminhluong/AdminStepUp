// src/pages/productStats.js
export const productStats = [
    { id: 1, name: "Áo thun trắng", total: 100, sold: 60 },
    { id: 2, name: "Quần jean xanh", total: 200, sold: 150 },
    { id: 3, name: "Áo sơ mi", total: 80, sold: 40 },
  ].map((item) => {
    const soldPercent = (item.sold / item.total) * 100;
    const remainingPercent = 100 - soldPercent;
    return {
      ...item,
      soldPercent,
      remainingPercent,
    };
  });
  