# admin-dashboard
# admin-dashboard

//bảng products
//product-variants bảng lưu sản phẩm biến thể
//product-attribute-variant lưu id của product-variants và id của bảng attribute-variant 
