import React, { useState, useEffect } from "react";
import { db } from "../firebase/firebaseConfig";
import {
  message,
  Button,
  Table,
  Modal,
  Form,
  Input,
  Select,
  Switch,
} from "antd";
import { PlusOutlined } from "@ant-design/icons";
import {
  collection,
  addDoc,
  updateDoc,
  doc,
  onSnapshot,
} from "firebase/firestore";

const Users = () => {
  const [users, setUsers] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [form] = Form.useForm();

  useEffect(() => {
    const storedUsers = localStorage.getItem("users");
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    }

    const unsubscribe = onSnapshot(collection(db, "users"), (snapshot) => {
      const userList = snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          ...data,
          active: data.active ?? true, // Mặc định true nếu chưa có
        };
      });
      setUsers(userList);
      localStorage.setItem("users", JSON.stringify(userList));
    });

    return () => unsubscribe();
  }, []);

  const handleAddOrUpdateUser = async (values) => {
    try {
      const dataToSave = {
        ...values,
        active: selectedUser ? selectedUser.active : true,
      };

      if (selectedUser) {
        const userRef = doc(db, "users", selectedUser.id);
        await updateDoc(userRef, dataToSave);
        message.success("Cập nhật người dùng thành công!");
      } else {
        await addDoc(collection(db, "users"), dataToSave);
        message.success("Thêm người dùng mới thành công!");
      }
      setIsModalVisible(false);
      form.resetFields();
    } catch (error) {
      message.error("Có lỗi xảy ra!");
    }
  };

  const toggleUserStatus = async (id, status) => {
    try {
      const userRef = doc(db, "users", id);
      await updateDoc(userRef, { active: status });
    } catch (error) {
      message.error("Không thể cập nhật trạng thái.");
    }
  };

  const columns = [
    { title: "Họ tên", dataIndex: "name", key: "name" },
    { title: "Email", dataIndex: "email", key: "email" },
    { title: "Vai trò", dataIndex: "role", key: "role" },
    {
      title: "Trạng thái",
      key: "status",
      render: (_, record) => (
        <Switch
          checked={record.active}
          onChange={(checked) => toggleUserStatus(record.id, checked)}
          checkedChildren="Bật"
          unCheckedChildren="Tắt"
        />
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "10px",
          borderBottom: "1px solid #ddd",
        }}
      >
        <h1 style={{ margin: 0 }}>Users</h1>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => {
            setSelectedUser(null);
            form.resetFields();
            setIsModalVisible(true);
          }}
        >
          Thêm User
        </Button>
      </div>

      <Table
        columns={columns}
        dataSource={users}
        rowKey="id"
        style={{ marginTop: 16 }}
      />

      <Modal
        title={selectedUser ? "Chỉnh sửa User" : "Thêm User"}
        open={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        onOk={() => form.submit()}
      >
        <Form form={form} layout="vertical" onFinish={handleAddOrUpdateUser}>
          <Form.Item
            name="name"
            label="Họ tên"
            rules={[{ required: true, message: "Vui lòng nhập họ tên!" }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="email"
            label="Email"
            rules={[{ required: true, message: "Vui lòng nhập email!" }]}
          >
            <Input type="email" />
          </Form.Item>
          <Form.Item
            name="role"
            label="Vai trò"
            rules={[{ required: true, message: "Vui lòng chọn vai trò!" }]}
          >
            <Select>
              <Select.Option value="admin">Admin</Select.Option>
              <Select.Option value="user">User</Select.Option>
              <Select.Option value="moderator">Moderator</Select.Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default Users;
